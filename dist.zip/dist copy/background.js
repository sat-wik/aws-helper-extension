chrome.runtime.onInstalled.addListener(()=>{console.log("AWS Helper Extension Installed!")});
